#! /bin/bash
while true; do
    cp pic1.jpg pic.jpg
    sleep 1
    cp pic2.jpg pic.jpg
    sleep 1
done
