window.LiveReloadOptions = { host: 'localhost' };
require('../../../src/startup.js');

window.hellow = function hellow () {
  return 42;
};
